export default function Result() {
    return (
      <main className="min-h-screen">
        <section className="mx-auto max-w-7xl px-6 py-12">
          <h1 className="text-3xl font-bold text-slate-900"> Result </h1>
        </section>
      </main>
    );
  }
  