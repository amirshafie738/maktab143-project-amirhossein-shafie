"use client";

import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";

import { store } from "@/redux/store";
import { persistStore } from "redux-persist";

const persistor = persistStore(store);

type ReduxProviderProps = {
  children: React.ReactNode;
};

export default function ReduxProvider({
  children,
}: ReduxProviderProps) {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        {children}
      </PersistGate>
    </Provider>
  );
}